# Beat Up — Android Music Player

A dark-themed Android music player starter built with Kotlin, Jetpack Compose, and AndroidX Media3.

## Features
- Scans local music using Android MediaStore after audio permission is granted
- Background playback with Media3 MediaSessionService and lock-screen/media controls
- Search local songs by title or artist
- Play/pause, next, previous controls
- Play a direct online audio URL (HTTP/HTTPS MP3/AAC or supported HLS stream)
- GitHub Actions workflow builds a debug APK and publishes it as an artifact

## Online streaming note
This app accepts direct stream URLs. It does not include a licensed commercial music catalog, scrape music services, or bypass DRM. Use streams you own or are authorized to play. A web page URL is not necessarily a direct audio stream URL.

## Build on GitHub
1. Create a repository and upload the *contents* of this folder to the repository root.
2. Open **Actions** and run **Beat Up Android Build** (it also runs on pushes to `main` or `master`).
3. When the run succeeds, open the workflow run and download the `beat-up-debug-apk` artifact.

## Local build
Requires JDK 17, Android SDK platform 35, and Gradle 8.11.1 or compatible.

## Current limitations
This is an advanced starter, not a finished commercial streaming service. Online URL playback is direct-stream based; persistent playlists, persistent favorites, full equalizer UI, synchronized lyrics, account login, and licensed catalog integration require further implementation.
