package com.beatup.music

import android.Manifest
import android.content.ComponentName
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import java.util.concurrent.ExecutionException

private val Bg = Color(0xFF101016)
private val Panel = Color(0xFF1D1B27)
private val Purple = Color(0xFFAA8BFF)

class MainActivity : ComponentActivity() {
    private val tracks = mutableStateListOf<AudioTrack>()
    private var controller by mutableStateOf<MediaController?>(null)
    private var currentTitle by mutableStateOf("Choose a song")
    private var currentArtist by mutableStateOf("Your music. Your vibe.")
    private var isPlaying by mutableStateOf(false)
    private var permissionLauncher: androidx.activity.result.ActivityResultLauncher<String>? = null
    private var controllerFuture: ListenableFuture<MediaController>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        permissionLauncher = registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { granted -> if (granted) loadTracks() }

        val permission = if (Build.VERSION.SDK_INT >= 33) {
            Manifest.permission.READ_MEDIA_AUDIO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
            loadTracks()
        }

        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener({
            try {
                controller = controllerFuture?.get()
                controller?.addListener(object : Player.Listener {
                    override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
                    override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                        currentTitle = mediaItem?.mediaMetadata?.title?.toString() ?: "Choose a song"
                        currentArtist = mediaItem?.mediaMetadata?.artist?.toString() ?: "Your music. Your vibe."
                    }
                })
            } catch (_: Exception) { }
        }, ContextCompat.getMainExecutor(this))

        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                background = Bg, surface = Panel, primary = Purple
            )) {
                BeatUpScreen(
                    tracks = tracks,
                    title = currentTitle,
                    artist = currentArtist,
                    playing = isPlaying,
                    onRequestPermission = { permissionLauncher?.launch(permission) },
                    onPlayTrack = { index -> playTrack(index) },
                    onTogglePlayback = {
                        controller?.let { if (it.isPlaying) it.pause() else it.play() }
                    },
                    onNext = { controller?.seekToNextMediaItem() },
                    onPrevious = { controller?.seekToPreviousMediaItem() }
                )
            }
        }
    }

    private fun loadTracks() {
        tracks.clear()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        contentResolver.query(collection, projection, selection, null,
            "${MediaStore.Audio.Media.TITLE} ASC")?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                tracks.add(AudioTrack(
                    id = id,
                    title = cursor.getString(titleCol) ?: "Unknown title",
                    artist = cursor.getString(artistCol) ?: "Unknown artist",
                    album = cursor.getString(albumCol) ?: "Unknown album",
                    durationMs = cursor.getLong(durationCol),
                    uri = android.content.ContentUris.withAppendedId(collection, id)
                ))
            }
        }
    }

    private fun playTrack(index: Int) {
        val player = controller ?: return
        val items = tracks.map { track ->
            MediaItem.Builder()
                .setUri(track.uri)
                .setMediaMetadata(
                    androidx.media3.common.MediaMetadata.Builder()
                        .setTitle(track.title)
                        .setArtist(track.artist)
                        .setAlbumTitle(track.album)
                        .build()
                )
                .build()
        }
        player.setMediaItems(items, index, 0L)
        player.prepare()
        player.play()
    }

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        super.onDestroy()
    }
}

@Composable
private fun BeatUpScreen(
    tracks: List<AudioTrack>,
    title: String,
    artist: String,
    playing: Boolean,
    onRequestPermission: () -> Unit,
    onPlayTrack: (Int) -> Unit,
    onTogglePlayback: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    var favorites by remember { mutableStateOf(setOf<Long>()) }
    val visibleTracks = tracks.withIndex().filter {
        it.value.title.contains(query, true) || it.value.artist.contains(query, true)
    }

    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar(containerColor = Panel) {
                NavigationBarItem(
                    selected = true, onClick = {},
                    icon = { Icon(Icons.Default.LibraryMusic, null) },
                    label = { Text("Library") }
                )
                NavigationBarItem(
                    selected = false, onClick = {},
                    icon = { Icon(Icons.Default.FavoriteBorder, null) },
                    label = { Text("Favorites (${favorites.size})") }
                )
            }
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().background(Bg).padding(padding).padding(18.dp)
        ) {
            Text("beat up", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text("Your music. Your vibe.", color = Color.LightGray)
            Spacer(Modifier.height(18.dp))
            OutlinedTextField(
                value = query, onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Search songs or artists") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                singleLine = true, shape = RoundedCornerShape(16.dp)
            )
            Spacer(Modifier.height(16.dp))
            Text("Your Library", fontSize = 21.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            if (tracks.isEmpty()) {
                Box(
                    Modifier.fillMaxWidth().weight(1f)
                        .background(Brush.linearGradient(listOf(Color(0xFF33264F), Panel)), RoundedCornerShape(22.dp))
                        .clickable(onClick = onRequestPermission),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.LibraryMusic, null, tint = Purple, modifier = Modifier.size(58.dp))
                        Spacer(Modifier.height(12.dp))
                        Text("Find music on your phone", color = Color.White, fontWeight = FontWeight.Medium)
                        Text("Tap here to allow audio access", color = Color.LightGray)
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = onRequestPermission) { Text("Allow access") }
                    }
                }
            } else {
                LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(visibleTracks, key = { it.value.id }) { indexed ->
                        val track = indexed.value
                        Row(
                            Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp))
                                .clickable { onPlayTrack(indexed.index) }.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                Modifier.size(46.dp).background(Color(0xFF34284D), RoundedCornerShape(10.dp)),
                                contentAlignment = Alignment.Center
                            ) { Icon(Icons.Default.LibraryMusic, null, tint = Purple) }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(track.title, color = Color.White, maxLines = 1, fontWeight = FontWeight.Medium)
                                Text(track.artist, color = Color.LightGray, maxLines = 1, fontSize = 12.sp)
                            }
                            IconButton(onClick = {
                                favorites = if (track.id in favorites) favorites - track.id else favorites + track.id
                            }) {
                                Icon(
                                    Icons.Default.FavoriteBorder, null,
                                    tint = if (track.id in favorites) Purple else Color.LightGray
                                )
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(
                Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(title, color = Color.White, maxLines = 1, fontWeight = FontWeight.SemiBold)
                    Text(artist, color = Color.LightGray, maxLines = 1, fontSize = 12.sp)
                }
                IconButton(onClick = onPrevious) { Icon(Icons.Default.SkipPrevious, "Previous", tint = Color.White) }
                IconButton(onClick = onTogglePlayback) {
                    Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, "Play or pause", tint = Purple)
                }
                IconButton(onClick = onNext) { Icon(Icons.Default.SkipNext, "Next", tint = Color.White) }
            }
        }
    }
}
