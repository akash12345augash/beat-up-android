# Beat Up 🎧

A modern dark Android music player starter built with **Kotlin**, **Jetpack Compose**, and **AndroidX Media3**.

## Features in this starter
- Dark Beat Up library interface
- Scan local audio with Android MediaStore
- Search tracks by title or artist
- Play, pause, previous and next
- Media3 playback service and media-session notification support
- Basic favorites toggle (currently in memory)

## Build locally
1. Install Android Studio and Android SDK 35.
2. Open this repository in Android Studio.
3. Use JDK 17 if prompted and allow Gradle sync to finish.
4. Connect an Android device or launch an emulator.
5. Press **Run**.

## Upload this project to GitHub
1. Create a new empty repository on GitHub, for example `beat-up-android`.
2. Extract this ZIP.
3. Upload the extracted project files and folders to the repository root (not the ZIP itself).
4. Commit the files.
5. Open the repository in Android Studio, or use GitHub Actions to run the build workflow.

## GitHub Actions
A workflow is included at `.github/workflows/android-build.yml`. It builds the debug APK and uploads it as a workflow artifact.

## Current limitations
This is a starter, not a finished commercial app. Favorites reset when the app process restarts. Custom playlists, persistent storage, album-art rendering, seek bar, equalizer/bass boost, lyrics, and a dedicated now-playing screen remain to be implemented. Test on a real Android device before release.

## Tech stack
- Kotlin
- Jetpack Compose / Material 3
- AndroidX Media3 ExoPlayer and MediaSession
- Minimum Android version: API 26
